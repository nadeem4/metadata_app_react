module.exports = {
  PORT: process.env.PORT || '3001'
}
