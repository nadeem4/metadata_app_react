module.exports = {
  "/api": {
    "/hello": {
      get: "hello.json"
    },
  }
}