## Mock api

Mocks all the endpoints mentioned in swagger

### Verification:

* run `npm i`

* run `npm start`